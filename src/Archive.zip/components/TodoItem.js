import React from 'react';

const TodoItem = ({todo, remove}) => {
	return (
		<div 
			className="ui segment"
			id={todo.id}
			onClick={() => {remove(todo.id)}}
		>
			{todo.content}
		</div>
	);
};

export default TodoItem;